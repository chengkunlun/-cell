//
//  LCVItem.m
//  LCVesper
//
//  Created by liuyi on 14-4-8.
//  Copyright (c) 2014年 Lucifer. All rights reserved.
//

#import "LCVItem.h"

@implementation LCVItem

@end
