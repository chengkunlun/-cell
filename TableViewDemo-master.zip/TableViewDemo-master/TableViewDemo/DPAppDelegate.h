//
//  DPAppDelegate.h
//  TableViewDemo
//
//  Created by haowenliang on 14-5-8.
//  Copyright (c) 2014年 dpsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DPAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
